
## HOF's   and   DOM


- CRUD => create , read(access) , update , delete

- Data => [{} , {}]
   -- document.get
   -- document.querySelector  - All

- Create =>    document => object
     -- document.createElement("tag")
     -- parentTag.append(childs , child2 , child3)

- Update => let img = document.querySelector("img")
            <!-- element.attributName = "value" -->
            img.src = "link"
            img.alt = "text"

            [{} , {}]

            <!-- - map , return ele - forEach -->


- search , delete , sort

- search => input box => get input for searching
            - input => event => click => 
    let value = we have the input value
            [{} , {} ]

            filter => value === title

            [{}]

- win + .            

- select
- hover => 
  if(hover){
    container.append(div)
  }

  css {
    position : relative;
    top ; 
  }