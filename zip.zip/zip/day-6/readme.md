# html => 

100 products => 1000 => 10000

<div>
  <h2></h2>
  <p></p>
  <img>
</div>

# DOM  => document object model

connection b/w HTML and JS

JS => object => DOM

## Access 
 getElementByID , ElementsByTagName , className

 querySelector("#") => [] . []

 {
    font-family
 }

## modify

text => element.style.fontSize = "20px" , fontFamily

attribuit => element.src
          => a.href

## event

<!-- click , change , -->

2 ways => html dependent

--------
<button  >press</button>

------

button.addEventListener(event , callback function)
button.addEventListener("click" , call)

## create

- createElement()
- parent.append(childs)
