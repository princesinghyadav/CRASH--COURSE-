// function multiplicaionTable(numb){
//     // console.log('hi')
//     var count = 1
//     while(count <= 10){
//          console.log(numb*count)
//          count++
//     }
// }

// multiplicaionTable(10)
// var count = 1
// while(count <= 10){
//   count++
// }

// for(var i = 0 ; i<=10 ; i++  ){
//     console.log(i)
// }



// function multiplicaionTable(num){
//     let str = ""
//     for(var i = 1 ; i<= 10 ; i++){
//         str = str + num*i + " "
//     }
//     console.log(str)
// }

// // 1 =>  "" + 5*1 + " " => "5 "
// // 2 => "5 " + 5*2 + " " => "5 10 "

// multiplicaionTable(5)

// storage of data => data structures

// var id = "1 2 3 4 5 6 7 8"
//      //   0123456789
// // str => places => index = 0       

// console.log(id[0])



// var str = "1 2 3 4 5"

// str[0] = 10

// console.log(str[0])

// var arr = [1,2,3,4,5]

// arr[0] = 11

// console.log(arr[0])

// some number and i wanna double those

var myArr = [2 , 4 , 6 , 9]

for(var i = 0 ; i < myArr.length ; i++){
    myArr[i] = myArr[i]*2
}
console.log(myArr)