// localstorage

// localStorage.setItem("dummy" , "hello world")


// let value = localStorage.getItem("dummy")

// console.log(typeof value)

// let arr = [1,2,3,4,]

// // ("name of key" , arr)

// localStorage.setItem("arr" , arr)

// localStorage.setItem("obj" , {a:1 , b:2})

// let value2 = localStorage.getItem('arr')
// let value3 = localStorage.getItem("obj")

// console.log(typeof value2)
// console.log(typeof value3)

// localStorage => non-primitive => primitive

// JSON => js object notation

// console.log(typeof [1,2,3])


// let arr = [1,2,3,4,5]

// localStorage.setItem("array" , JSON.stringify(arr))

// let value = JSON.parse(localStorage.getItem("array"))

// console.log(typeof value)


// key  |   value

// localStorage.setItem(key , value)
// localStorage => non-primitive => primitive
// localStorage.setItem(key , JSON.stringify(value))

// localStorage.getItem(key)
// JSON.parse(localStorage.getItem(key))

// localStorage.setItem("array" , ["str1" , "str2"])

// localStorage.removeItem("array")

// localStorage.clear()
