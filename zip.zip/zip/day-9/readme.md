## LocalStorage 

- Pesisting the data (or saving and loading the data)
- sharing information between different pages

Homepage | Product Listing page | cart Page | login page | signup page / register page